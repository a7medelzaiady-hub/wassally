import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'cart_model.dart';

/// توصيل مجاني لأول طلب.
///
/// العميل مؤهّل لو مفيش أي طلب قديم باسمه. وقت الطلب بنكتب مستند
/// first_orders/{uid} في نفس الـ batch، وقواعد الأمان بتسمح برسوم صفر
/// بس لو المستند ده لسه ما اتكتبش قبل كده (يعني مرة واحدة بس لكل حساب).
class FirstOrderService {
  const FirstOrderService._();

  /// هل العميل الحالي مؤهّل للتوصيل المجاني دلوقتي؟ (للواجهة)
  static final ValueNotifier<bool> eligible = ValueNotifier<bool>(false);

  /// بتفحص من Firestore وتحدّث [eligible] والسلة.
  static Future<bool> refresh() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    var ok = false;
    if (uid != null) {
      try {
        final orders = await FirebaseFirestore.instance
            .collection('orders')
            .where('userId', isEqualTo: uid)
            .limit(1)
            .get();
        ok = orders.docs.isEmpty;
        if (ok) {
          // لو المستند موجود يبقى استخدمها قبل كده (حتى لو الطلب اتمسح/اتلغى).
          try {
            final marker = await FirebaseFirestore.instance
                .collection('first_orders')
                .doc(uid)
                .get();
            if (marker.exists) ok = false;
          } catch (_) {}
        }
      } catch (e) {
        debugPrint('First order check error: $e');
        ok = false;
      }
    }
    eligible.value = ok;
    cart.setFreeDelivery(ok);
    return ok;
  }

  static String _seenKey(String uid) => 'free_delivery_popup_seen_$uid';

  /// هل نعرض نافذة "توصيل مجاني لأول طلب" تلقائيًا؟ (مرة واحدة لكل حساب)
  static Future<bool> shouldAutoShowPopup() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null || !eligible.value) return false;
    try {
      final prefs = await SharedPreferences.getInstance();
      return !(prefs.getBool(_seenKey(uid)) ?? false);
    } catch (_) {
      return false;
    }
  }

  static Future<void> markPopupSeen() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_seenKey(uid), true);
    } catch (_) {}
  }
}
