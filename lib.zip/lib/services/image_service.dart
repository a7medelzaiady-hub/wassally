import 'dart:convert';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

/// رفع الصور على Cloudinary بتوقيع من السيرفر (Cloud Function اسمها signUpload).
/// مفيش unsigned preset مفتوح، فمحدّش يقدر يرفع غير المدير وأصحاب المحلات (وبعد App Check).
class ImageService {
  const ImageService._();

  static Future<Map<String, dynamic>> _sign(
    String folder, {
    String? storeId,
  }) async {
    final res = await FirebaseFunctions.instanceFor(region: 'europe-west3')
        .httpsCallable('signUpload')
        .call<dynamic>({
          'folder': folder,
          if (storeId != null) 'storeId': storeId,
        });
    return Map<String, dynamic>.from(res.data as Map);
  }

  /// بيفتح معرض الصور في الموبايل، وبعد ما تختار صورة بيرفعها على Cloudinary
  /// في المجلد [folder] (stores / products / banners) وبيرجّع رابط الصورة (https).
  ///
  /// بيرجّع null لو المستخدم لغى الاختيار. ولو الرفع فشل بيرمي استثناء
  /// (عشان الشاشة تعرض رسالة الخطأ بدل ما يفشل في صمت).
  static Future<String?> pickAndUpload(String folder, {String? storeId}) async {
    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 1280, // تصغير الصورة قبل الرفع لتوفير الحجم والسرعة
      imageQuality: 80,
    );
    if (picked == null) return null;

    final bytes = await picked.readAsBytes();
    // حد أقصى 5MB قبل الرفع.
    if (bytes.length > 5 * 1024 * 1024) {
      throw StateError('الصورة كبيرة (أقصى حجم 5MB)');
    }

    final sig = await _sign(folder, storeId: storeId);
    final uri = Uri.parse(
      'https://api.cloudinary.com/v1_1/${sig['cloudName']}/image/upload',
    );
    final request = http.MultipartRequest('POST', uri)
      ..fields['api_key'] = '${sig['apiKey']}'
      ..fields['timestamp'] = '${sig['timestamp']}'
      ..fields['folder'] = '${sig['folder']}'
      ..fields['allowed_formats'] = '${sig['allowedFormats']}'
      ..fields['signature'] = '${sig['signature']}'
      ..files.add(
        http.MultipartFile.fromBytes(
          'file',
          bytes,
          filename: '${DateTime.now().millisecondsSinceEpoch}.jpg',
        ),
      );

    final response = await http.Response.fromStream(
      await request.send().timeout(const Duration(seconds: 60)),
    );
    if (response.statusCode != 200) {
      throw StateError('Upload failed: ${response.statusCode}');
    }
    final url = (jsonDecode(response.body) as Map)['secure_url'] as String?;
    if (url == null || url.isEmpty) throw StateError('No URL returned');
    return url;
  }
}
