import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/brand.dart';

const Color _kDeepBrown = Color(0xFF3A1414);
const Color _kLime = Color(0xFFD7F205);

/// نافذة "توصيل مجاني لأول طلب" (تطلع من تحت زي تطبيقات التوصيل الكبيرة).
Future<void> showFreeDeliverySheet(
  BuildContext context, {
  VoidCallback? onOrderNow,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
    ),
    builder: (ctx) => Directionality(
      textDirection: TextDirection.rtl,
      child: _FreeDeliverySheet(
        onOrderNow: () {
          Navigator.of(ctx).pop();
          onOrderNow?.call();
        },
      ),
    ),
  );
}

class _FreeDeliverySheet extends StatelessWidget {
  final VoidCallback onOrderNow;
  const _FreeDeliverySheet({required this.onOrderNow});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Align(
              alignment: AlignmentDirectional.centerEnd,
              child: Material(
                color: Colors.white,
                shape: CircleBorder(
                  side: BorderSide(color: Colors.grey.shade300),
                ),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () => Navigator.of(context).pop(),
                  child: const SizedBox(
                    width: 42,
                    height: 42,
                    child: Icon(Icons.close_rounded, size: 22),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 18),
            Transform.rotate(
              angle: -0.02,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  vertical: 14,
                  horizontal: 12,
                ),
                color: _kDeepBrown,
                child: const FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    'توصيل مجاني لأول طلب',
                    style: TextStyle(
                      color: _kLime,
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 28),
            const Center(child: _Illustration()),
            const SizedBox(height: 28),
            SizedBox(
              height: 54,
              child: FilledButton(
                onPressed: onOrderNow,
                style: FilledButton.styleFrom(
                  shape: const StadiumBorder(),
                  textStyle: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                child: const Text('اطلب الآن'),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'العرض لأول طلب بس، والتوصيل بيتخصم تلقائيًا وقت تأكيد الطلب.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12.5,
                height: 1.4,
                color: Colors.grey.shade600,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Illustration extends StatelessWidget {
  const _Illustration();

  Widget _star(double size, Color color, double angle) => Transform.rotate(
    angle: angle,
    child: Icon(Icons.star_rounded, size: size, color: color),
  );

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 260,
      height: 190,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(top: 24, left: 22, child: _star(26, Brand.green, 0.3)),
          Positioned(top: 24, right: 22, child: _star(26, Brand.green, -0.3)),
          Positioned(
            bottom: 52,
            left: 4,
            child: _star(30, _kDeepBrown, math.pi / 8),
          ),
          Positioned(
            bottom: 52,
            right: 4,
            child: _star(30, _kDeepBrown, -math.pi / 8),
          ),
          Positioned(
            top: 0,
            child: Text(
              'توصيل\nمجاني',
              textAlign: TextAlign.center,
              style: TextStyle(
                height: 1.05,
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Brand.ink,
              ),
            ),
          ),
          Positioned(
            top: 46,
            child: Icon(
              Icons.delivery_dining_rounded,
              size: 92,
              color: Brand.green,
            ),
          ),
          Positioned(
            bottom: 12,
            child: Transform.rotate(
              angle: -0.05,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 22,
                  vertical: 8,
                ),
                color: Brand.green,
                child: const Text(
                  'الطلب الأول',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// شريط برتقالي ثابت أسفل الرئيسية: "توصيل مجاني لأول طلب". الضغط عليه بيفتح النافذة.
class FreeDeliveryStrip extends StatelessWidget {
  final VoidCallback onTap;
  const FreeDeliveryStrip({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Brand.green,
      borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
      child: InkWell(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
          child: Row(
            children: [
              const Icon(
                Icons.delivery_dining_rounded,
                color: Colors.white,
                size: 24,
              ),
              const SizedBox(width: 10),
              const Text(
                'توصيل مجاني لأول طلب',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 3,
                ),
                decoration: BoxDecoration(
                  color: _kDeepBrown,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'مجاني',
                  style: TextStyle(
                    color: _kLime,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              const Icon(Icons.keyboard_arrow_up_rounded, color: Colors.white),
            ],
          ),
        ),
      ),
    );
  }
}
